
public interface IProcess<T> {
	public String getType();
	public int getPriority();
}
