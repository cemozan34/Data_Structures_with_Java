public interface Orderable {//interface and its functions
	public void updatePrice();
	public void updateStock();
}
